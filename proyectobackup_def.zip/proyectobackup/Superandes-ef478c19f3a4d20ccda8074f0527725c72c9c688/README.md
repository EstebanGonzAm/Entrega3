# Entrega 3 🛒 Superandes - Sistema de Gestión de Inventarios y Transacciones

Este repositorio contiene el proyecto **Superandes**, una aplicación diseñada para gestionar inventarios y transacciones en una tienda. Este proyecto forma parte del curso **Sistemas Transaccionales (ISIS2304)**.

**Esteban Gonzalez Amaya**
